/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bus.management;

/**
 *
 * @author ussl_04
 */
public class Busmanagement {

    public static void main(String[] args) {
        MainScreen ms = new MainScreen();
        ms.setLocationRelativeTo(null);
        ms.setVisible(true);
    }

}
